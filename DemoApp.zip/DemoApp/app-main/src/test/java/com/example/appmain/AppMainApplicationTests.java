package com.example.appmain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
